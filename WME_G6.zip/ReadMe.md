# WME_G6
WME exercise of group 6
Tian Zhao, Yanchen Zhao
