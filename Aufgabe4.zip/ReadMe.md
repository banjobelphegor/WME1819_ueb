
WME exercise of group 23
Yanchen Zhao, Gabriella Novachka
