//alert("No ajax calls implemented ;)");

var data;

window.onload = function() {
    $.getJSON("/getData", function(result){
        data = result;

        // Loading properties into select
        // and initializing table head
        var jsonObj = result[0];
        var tableHead = '';
        var sel = document.getElementById("prop_selection");
        for (var property in jsonObj) {
            if (jsonObj.hasOwnProperty(property)) {
                var opt = document.createElement('option'); // create new option element
                // create text node to add to option element (opt)
                opt.appendChild(document.createTextNode(property));
                opt.className = "text_visible";
                //opt.value = property; // set value property of opt
                sel.appendChild(opt); // add opt to end of select box (sel)
                tableHead += '<th>' + property + '</th>';
            }
            document.getElementById("table_head").innerHTML = tableHead;
        }


        var l = result.length;
        var tableContent = '';
        for (var i = 0; i < l; i++) {
            tableContent += '<tr id="tr' + i + '">';
            for (var property in result[i]) {
                if (result[i].hasOwnProperty(property)) {
                    tableContent += '<td>' + result[i][property] + '</td>';
                }
            }
            tableContent += '</tr>';
        }
        document.getElementById("table_body").innerHTML = tableContent;
    });

}

function showSelectedProperty(isVisible){
    var tbl = document.getElementById("table_body");
    var sel = document.getElementById("prop_selection");
    var  selIndex = sel.selectedIndex + 1;
    if (isVisible){
        $('td:nth-child(' + selIndex + '),th:nth-child(' + selIndex + ')').show();
        sel.options[selIndex - 1].className = "text_visible";
    } else {
        $('td:nth-child(' + selIndex + '),th:nth-child(' + selIndex + ')').hide();
        sel.options[selIndex - 1].className = "text_hidden";
    }
}

function filterCountries() {

}