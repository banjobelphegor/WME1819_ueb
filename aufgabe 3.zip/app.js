// DO NOT CHANGE!
//init app with express, util, body-parser, csv2json
var express = require('express');
var app = express();
var sys = require('util');
var path = require('path');
var bodyParser = require('body-parser');
var Converter = require("csvtojson").Converter;
var fs = require("fs");
var jsonArr;


//register body-parser to handle json from res / req
app.use( bodyParser.json() );

//register public dir to serve static files (html, css, js)
app.use( express.static( path.join(__dirname, "public") ) );

var converter = new Converter();

//record_parsed will be emitted each csv row being processed
converter.on("end_parsed", function (jsonArray) {
    //console.log(jsonArray); //here is your result jsonarray

    jsonArr = jsonArray;

    /*var file = fs.createWriteStream('./world_data.json');
    file.on('error', function(err) { return console.error(err); });
    jsonArray.forEach(function(o) { file.write(JSON.stringify(o) + '\n'); });
    file.end();*/

    fs.writeFile('./world_data.json', JSON.stringify(jsonArray), function(err) {
        if (err) {
            return console.error(err);
        }
    });
});

fs.createReadStream("./world_data.csv").pipe(converter);

app.get('/getData', function (req, res) {
    res.end(JSON.stringify(jsonArr));
});

app.get('/filter', function(req, res) {
    var countryId = req.query.country_filter_id,
        countryRange = req.query.country_filter_range;
    //console.log("id = " + countryId + " range = " + countryRange);
});

// END DO NOT CHANGE!


/**************************************************************************
****************************** csv2json *********************************
**************************************************************************/

/**************************************************************************
********************** handle HTTP METHODS ***********************
**************************************************************************/


// DO NOT CHANGE!
// bind server to port
var server = app.listen(3000, function () {
    var host = server.address().address;
    var port = server.address().port;
    console.log('Example app listening at http://%s:%s', host, port);
});