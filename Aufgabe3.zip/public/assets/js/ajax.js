// get all items
function load_items(callback){
  $.ajax({
    type: "GET",
    url: "http://localhost:3000/items",
    dataType: "json",
    async: false,
    success: function(data){
      callback(data);
    },
    error: function(){
      alert('error');
    }
  });
}


// get all properties
function load_properties(callback){
  $.ajax({
    type: "GET",
    url: "http://localhost:3000/properties",
    dataType: "json",
    async: false,
    success: function(data){
      callback(data);
    },
    error: function(){
      alert('error');
    }
  });
}

var items;
var properties;
var prop_index;

$(document).ready(function(){
  //load properties via API
  load_properties(function(data){
    properties = data;
  });

  set_options(properties);

  prop_index = 0;
  refresh_table(prop_index);
});

//fulfill options with recieved properties from API
function set_options(properties){
  $.each(properties, function(key, value){
    $('#prop_selection')
     .append($("<option></option>")
     .attr("value", key)
     .text(value));
  });
}

//keep name and selected data
function item_filter(property_index, items){
  for(var i=0; i<items.length; i++){
    for(var key=0; key<=properties.length; key++){
      if(key == property_index && key!=1){
        //doesn't work??
        $("#show_selected_prop").click(function(){
          $("." + properties[key]).show();
        });
        $("#hide_selected_prop").click(function(){
          $("." + properties[key]).hide();
        });
      }
    }
  }
  return items;
}

//single item
function country_filter(callback){
  var id = $("#country_filter_id").val();
  $.ajax({
    type: "GET",
    url: "http://localhost:3000/items/:id",
    dataType: "json",
    async: false,
    success: function(data){
      callback(data);
    },
    error: function(){
      alert('error');
    }
  });
}

function country_range_filter(callback){
  var tmp = $("#country_filter_range").val();
  for(var i=0;i<tmp.length; i++){
    if (tmp[i] == '-') break;
  }
  //split string in textbox
  var id = tmp.slice(0,i);
  var id2 = tmp.slice(i+1, tmp.length);
  $.ajax({
    type: "GET",
    url: "http://localhost:3000/items/:id/:id2",
    dataType: "json",
    async: false,
    success: function(data){
      callback(data);
    },
    error: function(){
      alert('error');
    }
  });
}

//Pack up the relativ functions
function refresh_table(prop_index){
  //reload items

  load_items(function(data){
    items = data;
  });

  var filter_result;
  filter_result = item_filter(prop_index, items);

  //refresh the table
  set_table(filter_result);
}

function set_table(items){

  var tr = "<tr>";
  for (var i=0; i<items.length; i++){
    for (var k=0; k<properties.length; k++){
      tr += "<td class=\" " + properties[k] + " \">" + items[i][properties[k]]+ "</td>";
    }
    tr += "</tr>";

    /*tr = "<tr><td>" + items[i].id
    + "</td><td>" + items[i].name
    + "</td></tr>";*/
    $('#table_body').append(tr);
  }

  //as default
  if (prop_index <= 0 || prop_index>properties.length){
    $(".gdp_per_capita").hide();
    $(".gdp_per_capita_growth").hide();
    $(".inflation_annual").hide();
    $(".life_expectancy").hide();
    $(".military_expenditure_percent_of_gdp").hide();
    $(".gps_lat").hide();
    $(".gps_long").hide();
  }
}
