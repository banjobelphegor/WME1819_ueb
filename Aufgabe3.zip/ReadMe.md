
WME exercise of group 23
Yanchen Zhao, Gabriella Novachka

## Installing/Running the Application

1. Install dependencies by running `npm install` (a list of all dependencies can be found in the package.json)
2. You can update existing dependencies by running `npm update`
3. Start the application by running `npm start`
4. Open a browser at `http://localhost:3000/` 